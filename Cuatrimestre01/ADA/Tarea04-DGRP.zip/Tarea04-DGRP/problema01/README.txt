
-Para ejcutarlo en Windows

g++ problema01 -o prog
prog < instancias[i]\pruebas\prueba[i] > instancias[i]\pruebas\salidas\saida[i]


-Para ejcutarlo en linux

g++ problema01 -o prog
prog < instancias[i]/pruebas/prueba[i] > instancias[i]/pruebas/salidas/saida[i]


donde la i se cambiará por numeros del 1 al 10
