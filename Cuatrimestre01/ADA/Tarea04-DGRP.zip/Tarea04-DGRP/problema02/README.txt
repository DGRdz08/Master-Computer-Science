
-Para ejcutarlo en Windows

g++ problema02 -o prog
prog < pruebas\prueba[i] 

-Para ejcutarlo en linux o macOS

g++ problema01 -o prog
./prog <  pruebas/prueba[i] 

donde cambiaremos por ese indice i, al numero de instancias que consideraremos, ya sea 25, 100 o 50