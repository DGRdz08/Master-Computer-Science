
-Para ejcutarlo en Windows

g++ problema02 -o prog
prog <  dirijidos/dir50F.txt 

-Para ejcutarlo en linux o macOS

g++ problema01 -o prog
./prog <  dirijidos/dir50F.txt 


donde cambiaremos al numero de instancias que consideraremos, 
ya sea 25, 100 o 50 y si deseamos que nos de F para No es bipartita 
y V para Bipartita

****Falla para algunos casos de no dirigidos